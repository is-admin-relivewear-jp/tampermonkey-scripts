// ==UserScript==
// @name         TV通販用shopify返金処理連続実行
// @namespace    http://tampermonkey.net/
// @version      2025-01-27
// @description  try to take over the world!
// @author       You
// @match        https://admin.shopify.com/store/16bc5d-2/orders
// @icon         https://www.google.com/s2/favicons?sz=64&domain=shopify.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    /*
    window.onload = function() {
        let intervalCount = 0;

        let timerId = setInterval(function() {
            let buttons = document.getElementsByTagName("button");

            if (buttons && 0 < buttons.length) {
                let el = Array.from(buttons).find(e => e.getAttribute("aria-label") == "検索と絞り込みの注文");

                if (el) {
                    el.click();
                }
            }

            if (100 < intervalCount++) {
                clearInterval(timerId);
            }
        }, 500);
    };
    */
})();