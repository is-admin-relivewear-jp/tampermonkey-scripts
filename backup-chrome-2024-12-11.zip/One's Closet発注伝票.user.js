// ==UserScript==
// @name         One's Closet発注伝票
// @namespace    http://tampermonkey.net/
// @version      2024-12-04
// @description  try to take over the world!
// @author       Shigekatsu Sasaki
// @match        https://ones-closet.com/app/purchaseOrder.php
// @icon         https://www.google.com/s2/favicons?sz=64&domain=ones-closet.com
// @grant        none
// @require      https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.30.1/moment.js
// @require      https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.30.1/locale/ja.js
// ==/UserScript==

// @see https://github.com/Tampermonkey/tampermonkey/issues/475
const jp_relivewear_tm_loadScriptSync = function(url){
    const t = new Date().getTime();
    const xhr = new XMLHttpRequest();
    xhr.open("GET", url + "?t=" + t, false);
    // 以下を指定すると読み込み時にエラー
    // GitHubのrawファイルは最低でも5分キャッシュされ、回避は難しそう。
    // @see https://stackoverflow.com/questions/62785962/get-raw-file-from-github-without-waiting-for-5-minute-cache-update
//    xhr.setRequestHeader("Pragma", "no-cache");
//    xhr.setRequestHeader("Cache-Control", "no-cache");
//    xhr.setRequestHeader("If-Modified-Since", "Thu, 01 Jun 1970 00:00:00 GMT");
    xhr.send(null);

    if (xhr.status === 200) {
        eval(xhr.responseText);
    }
    else {
        console.error(`Error loading script: ${xhr.status} ${xhr.statusText}`);
    }
};

jp_relivewear_tm_loadScriptSync("https://raw.githubusercontent.com/is-admin-relivewear-jp/tampermonkey-scripts/refs/heads/main/common.js");
jp_relivewear_tm_loadScriptSync("https://raw.githubusercontent.com/is-admin-relivewear-jp/tampermonkey-scripts/refs/heads/main/purchaseOrder.js");
