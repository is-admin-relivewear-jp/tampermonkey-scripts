// ==UserScript==
// @name         One's Closet Exportセット
// @namespace    http://tampermonkey.net/
// @version      2025-06-27
// @description  try to take over the world!
// @author       Shigekatsu Sasaki
// @match        https://ones-closet.com/app/exportFormat.php
// @icon         https://www.google.com/s2/favicons?sz=64&domain=ones-closet.com
// @grant        none
// @require      https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.30.1/moment.js
// @require      https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.30.1/locale/ja.js
// ==/UserScript==

// @see https://github.com/Tampermonkey/tampermonkey/issues/475
const jp_relivewear_tm_loadScriptSync = function(url){
    const t = new Date().getTime();
    const xhr = new XMLHttpRequest();
    xhr.open("GET", url + "?t=" + t, false);
    // 以下を指定すると読み込み時にエラー
    // GitHubのrawファイルは最低でも5分キャッシュされ、回避は難しそう。
    // @see https://stackoverflow.com/questions/62785962/get-raw-file-from-github-without-waiting-for-5-minute-cache-update
//    xhr.setRequestHeader("Pragma", "no-cache");
//    xhr.setRequestHeader("Cache-Control", "no-cache");
//    xhr.setRequestHeader("If-Modified-Since", "Thu, 01 Jun 1970 00:00:00 GMT");
    xhr.send(null);

    if (xhr.status === 200) {
        eval(xhr.responseText);
    }
    else {
        console.error(`Error loading script: ${xhr.status} ${xhr.statusText}`);
    }
};

jp_relivewear_tm_loadScriptSync("https://raw.githubusercontent.com/is-admin-relivewear-jp/tampermonkey-scripts/refs/heads/main/common.js");
// jp_relivewear_tm_loadScriptSync("https://raw.githubusercontent.com/is-admin-relivewear-jp/tampermonkey-scripts/refs/heads/main/exportFormat.js");

(function() {
    'use strict';

    // $.fn.jQuery => 1.11.0
    // 日付の処理にはmoment.jsを利用
    // @see https://qiita.com/taizo/items/3a5505308ca2e303c099

    const f1 = function(){
        // 表示ボタンクリック
        setTimeout(function(){
            const p_list = [];

            const option_count = $("#detail_addSelectValue").find("option").length;
//            const option_count = 10;
            console.log("option count", option_count);

            for (let i = 0 ; i < option_count ; i++) {
                p_list.push(
                    () => {
                        return new Promise((resolve, reject) => {
                            setTimeout(() => {
                                // ＋ボタンクリック
                                $("#detail_addButton").click();

                                // 次のoptionを選択
                                const option = $("#detail_addSelectValue").find("option:selected").next();
                                $("#detail_addSelectValue").val(option.val()).change();

                                // 日付系項目で日付フォーマットが表示されていた場合
                                const el = $("#detail_dateFormat");

                                if (el.is(":visible")) {
                                    el.val("Y/m/d");
                                }

                                resolve();
                            }, 500);
                        });
                    }
                );
            }

            const run = async () => {
                for (let i = 0 ; i < p_list.length ; i++) {
                    await p_list[i]();
                }
            };
            run();
        }, 500);
    };

    setTimeout(function(){
        jp.relivewear.tm.confirm(
            "自動Exportセット作成を実行しますか？（一覧画面ではなく編集画面で実行）",
            {
                "はい": f1,
            }
        );
    }, 1000);
})();
