// ==UserScript==
// @name         One's Closet商品元帳
// @namespace    http://tampermonkey.net/
// @version      2025-05-13
// @description  try to take over the world!
// @author       Shigekatsu Sasaki
// @match        https://ones-closet.com/app/goodsLedger.php
// @icon         https://www.google.com/s2/favicons?sz=64&domain=ones-closet.com
// @grant        none
// @require      https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.30.1/moment.js
// @require      https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.30.1/locale/ja.js
// ==/UserScript==

// @see https://github.com/Tampermonkey/tampermonkey/issues/475
const jp_relivewear_tm_loadScriptSync = function(url){
    const t = new Date().getTime();
    const xhr = new XMLHttpRequest();
    xhr.open("GET", url + "?t=" + t, false);
    // 以下を指定すると読み込み時にエラー
    // GitHubのrawファイルは最低でも5分キャッシュされ、回避は難しそう。
    // @see https://stackoverflow.com/questions/62785962/get-raw-file-from-github-without-waiting-for-5-minute-cache-update
//    xhr.setRequestHeader("Pragma", "no-cache");
//    xhr.setRequestHeader("Cache-Control", "no-cache");
//    xhr.setRequestHeader("If-Modified-Since", "Thu, 01 Jun 1970 00:00:00 GMT");
    xhr.send(null);

    if (xhr.status === 200) {
        eval(xhr.responseText);
    }
    else {
        console.error(`Error loading script: ${xhr.status} ${xhr.statusText}`);
    }
};

jp_relivewear_tm_loadScriptSync("https://raw.githubusercontent.com/is-admin-relivewear-jp/tampermonkey-scripts/refs/heads/main/common.js");
//jp_relivewear_tm_loadScriptSync("https://raw.githubusercontent.com/is-admin-relivewear-jp/tampermonkey-scripts/refs/heads/main/goodsLedger.js");

/*
(function() {
    'use strict';

    // $.fn.jQuery => 1.11.0
    // 日付の処理にはmoment.jsを利用
    // @see https://qiita.com/taizo/items/3a5505308ca2e303c099

    const f1 = function() {
        // @see https://naomichi-h.hatenablog.com/entry/2021/09/16/163248

        const p1 = () => {
            return new Promise((resolve) => {
                // 検索ボタンクリック
                $("#list_query").click();

                setTimeout(() => {
                    $("#query_word").val("INU-003"); // 商品コード
                    $("#query_way").val("equal"); // である

                    // 表示ボタンクリック
                    $("#list_queryExec").click();

                    resolve();
                }, 500);
            });
        };

        const p2 = () => {
            return new Promise((resolve) => {
                setTimeout(() => {
                    // 明細の最初の行をダブルクリック
                    $("td.list_result_col2").first().find("div").dblclick();

                    resolve();
                }, 500);
            });
        };

        const p3 = () => {
            return new Promise((resolve) => {
                // 表示日付
                const ym_range_list = [
                    {from: "2025/04/01", to: "2025/04/30"},
                    {from: "2025/05/01", to: "2025/05/31"},
                ];

                // 拠点
                const location_list = [
                    "007", // NTM倉庫
                    "BB001", // 法人
                    "BB002", // 法人（緊急拠点）
                    "010", // カタログ販売要
                    "013", // NTM（TV通販分）
                ];

                // 色
                const color_list = [
//                    "-BEG",
                    "-BLK",
//                    "-WHT",
                ];

                // サイズ
                const size_list = [
                    "M",
                    "L",
                    "LL",
                ];
                // Promiseの配列
                const p_list = [];

                for (let h = 0 ; h < ym_range_list.length ; h++) {
                    const ym_from = ym_range_list[h].from;
                    const ym_to = ym_range_list[h].to;
                    const ym = ym_from.replaceAll("/", "").substring(0, 6);

                    for (let i = 0 ; i < location_list.length ; i++) {
                        for (let j = 0 ; j < color_list.length ; j++) {
                            for (let k = 0 ; k < size_list.length ; k++) {
                                p_list.push(
                                    () => {
                                        return new Promise((resolve, reject) => {
                                            setTimeout(() => {
                                                console.log(location_list[i], color_list[j], size_list[k]);

                                                $("#condition_from").val(ym_from);
                                                $("#condition_to").val(ym_to);
                                                $("#condition_location").val(location_list[i]);
                                                $("#condition_color").val(color_list[j]);
                                                $("#condition_size").val(size_list[k]).change();

                                                let count = 0;
                                                const timerId = setInterval(() => {
                                                    if ($('#blackpanel').is(":visible")) {
                                                        // Ajax処理中
                                                    }
                                                    else {
                                                        clearInterval(timerId);

                                                        const sku = $("#detail_goodsCode").text() + color_list[j] + size_list[k];

                                                        // goodsLedger.phpの861行目付近より抜き出し
                                                        // --------------------------------------------------------------------------------
                                                        // var header = '日付,区分,伝票番号,拠点名,取引先名,数量,在庫数,取置残,委託残,受託残,カスタム在庫数,注意事項'+'\r\n';
                                                        // header += '繰越,"","","","","",'+$('#rt_carry').text()+','+$('#rt_keepCarry').text()+','+$('#rt_consCarry').text()+','+$('#rt_customCarry').text()+',""';
                                                        var header = '拠点,SKU,日付,区分,伝票番号,拠点名,取引先名,数量,在庫数,取置残,委託残,受託残,カスタム在庫数,注意事項'+'\r\n';
                                                        header += '繰越,"","","","","","","",'+$('#rt_carry').text()+','+$('#rt_keepCarry').text()+','+$('#rt_consCarry').text()+','+$('#rt_customCarry').text()+',""';
                                                        var data = [];
                                                        $('.result_dt_tr').filter(':visible').each(function() {
                                                            var row = [];

                                                            row.push(dquote(location_list[i]));
                                                            row.push(dquote(sku));

                                                            row.push(dquote($(this).find('.rt_hCol1').text()));
                                                            row.push(dquote($(this).find('.rt_hCol2').text()));
                                                            row.push(dquote($(this).find('.rt_hCol3').text()));
                                                            row.push(dquote($(this).find('.rt_hCol4 div').text()));
                                                            row.push(dquote($(this).find('.rt_hCol11 div').text()));
                                                            row.push(dquote($(this).find('.rt_hCol5').text()));
                                                            row.push(dquote($(this).find('.rt_hCol6').text()));
                                                            row.push(dquote($(this).find('.rt_hCol7').text()));
                                                            row.push(dquote($(this).find('.rt_hCol8').text()));
                                                            row.push(dquote($(this).find('.rt_hCol14').text()));
                                                            row.push(dquote($(this).find('.rt_hCol12').text()));
                                                            row.push(dquote($(this).find('.rt_hCol9').text()));
                                                            data.push(row.join(','));
                                                        });
                                                        var csv = header + '\r\n' + data.join('\r\n') + '\r\n';
                                                        // var fileName = '商品元帳_'+getYmdHi()+'.csv';
                                                        var fileName = '商品元帳_' + ym + "_" + location_list[i] + "_" + sku + "_" + getYmdHi() + '.csv';
                                                        downloadFile(fileName, csv);
                                                        // --------------------------------------------------------------------------------

                                                        // Ajax処理完了
                                                        resolve();
                                                    }

                                                    // 1000*10ミリ秒（10秒）待っても明細が表示されない場合は処理中断
                                                    if (10 < count++) {
                                                        // alert("画面遷移に時間がかかりすぎたため処理を中断します。");
                                                        clearInterval(timerId);

                                                        reject();
                                                    }
                                                }, 1000);
                                            }, 1000);
                                        })
                                    }
                                );

                            }
                        }
                    }
                }

                const run = async () => {
                    for (let i = 0 ; i < p_list.length ; i++) {
                        await p_list[i]();
                    }
                };
                run();
            });
        };

        p1()
            .then(() => p2())
            .then(() => p3())
        ;

    };

    setTimeout(function(){
        jp.relivewear.tm.confirm(
            "自動書き出しを実行しますか？",
            {
                "はい（INU-003）": f1,
            },
            600
        );
    }, 1000);
})();
*/
